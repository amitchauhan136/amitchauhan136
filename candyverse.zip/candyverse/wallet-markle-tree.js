const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const Fortmatic = window.Fortmatic;
const evmChains = window.evmChains;
const tree = window.MerkleTree;
const keccak = window.keccak256;

let web3Modal
let provider;
let selectedAccount;
let remaningNFT;

$("#mint-nft").click(function(e) {
    mint();
});

$("#wallet-connect").click(function(e) {
    onConnect();
});

$('.do-min').click(function() {
    if (isNaN($('input[name=\'quantity\']').val() / 1) == false) {
        var quantity = $('input[name=\'quantity\']').val();
    } else {
        var quantity = 1;
    }
    if ($('input[name=\'quantity\']').val() > 1) {
        $('input[name=\'quantity\']').val(parseInt(quantity) - parseInt(1));
    }
    priceChnage();
});

$('.do-plus').click(function() {
    if (isNaN($('input[name=\'quantity\']').val() / 1) == false) {
        var quantity = $('input[name=\'quantity\']').val();
    } else {
        var quantity = 1;
    }
    $('input[name=\'quantity\']').val(parseInt(quantity) + parseInt(1));
    priceChnage();
});

$("#input-quantity").change(function(e) {
    priceChnage();
});

window.addEventListener('load', async () => {
    init();
});

async function onConnect() {
    console.log("Opening a dialog", web3Modal);
    try {
        provider = await web3Modal.connect();
    } catch (e) {
        console.log("Could not get a wallet connection", e);
        return;
    }
    provider.on("accountsChanged", (accounts) => {
        init2();
    });
    provider.on("chainChanged", (chainId) => {
        init2();
    });
    provider.on("networkChanged", (networkId) => {
        init2();
    });
    await init2();
}

var abi = [{"inputs":[{"internalType":"string","name":"baseURI","type":"string"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"id","type":"uint256"}],"name":"CreateMetaKongz","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"inputs":[],"name":"GIVEAWAY_MINTED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"GIVEAWAY_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_BY_MINT_IN_TRANSACTION","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_BY_MINT_PRESALE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_BY_MINT_SALE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PRESALE_MINTED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PRESALE_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PRESALE_PRICE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_MINTED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_PRICE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"baseTokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"merkleRoot","outputs":[{"internalType":"bytes32","name":"","type":"bytes32"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_count","type":"uint256"}],"name":"mintGiveawayNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_count","type":"uint256"},{"internalType":"bytes32[]","name":"merkleProof","type":"bytes32[]"}],"name":"mintPreSaleNFT","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_count","type":"uint256"}],"name":"mintSaleNFT","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bool","name":"val","type":"bool"}],"name":"pause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"presaleEnable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"saleEnable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"baseURI","type":"string"}],"name":"setBaseURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_status","type":"bool"}],"name":"setPreSaleStatus","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_status","type":"bool"}],"name":"setSaleStatus","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updateGiveawayLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes32","name":"newRoot","type":"bytes32"}],"name":"updateMerkleRoot","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updateMintLimitPerTransection","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updatePreSaleLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updatePreSaleMintLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newPrice","type":"uint256"}],"name":"updatePreSalePrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updateSaleMintLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newPrice","type":"uint256"}],"name":"updateSalePrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"users","outputs":[{"internalType":"uint256","name":"presalemint","type":"uint256"},{"internalType":"uint256","name":"salemint","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"}],"name":"walletOfOwner","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"}];
var contractAddress = '0x297f8Eb30b696560578cD45eF8D745637E844a71';
var userAddress = '';
var contract = undefined;
var saleEnable;
var presaleEnable;
var MintLimit=0;
var NFTprice=0;
var buttondisplay="Yes";
var MAX_BY_MINT_IN_TRANSACTION = 0;
var markelTree;

async function init() {
    let whitelistAddress = [
            "0x008636452aa0f0dC17260e43E6c55f43C71a937d",
            "0x008e118E87c4A19411C64165502460391A9001C8",
            "0x00C24c351571EdB6Db7A5616B5FF91c08BF1c218",
            "0x00cb5251d714fcbc5aee1976db97d5e135124744",
            "0x02002EC9Ca4527b23ca36339300a921FEb109844",
            "0x02C4769c07a453Ea221E403fdCC7a2203c9b1C4b",
            "0x02d549FfAB75B2F945992fB1e6C851b9cE81F190",
            "0x03fF18d6F1a9F90E7A37cd228629a159d6576598",
            "0x0409cF2db6d8038Ad33A2E59fFeA9f58BA313072",
            "0x043e5Ea7D6101f098D6A8390848459dc507931BC",
            "0x0466EacE323f1a0C6E9Af9861B44FdC145375235",
            "0x049232a962EC9F412e9295d6Aa746E568AFC7294",
            "0x04D725941898d965A4DdE8cB40590A9BEB193da3",
            "0x050974Aa9507Ac59d4f9c2B806B80f85e22D2DFA",
            "0x0533C7834189FDC1b0D191b55f31F9F1518B9553",
            "0x057EdC47EA5d0eDe6e1E4c014fFf9fd52AD52271",
            "0x0593Dd08D07Fb08479643edbC2916604D7304C06",
            "0x05E1Df6888dbefA858A6bd3BbF0229F2ADAF8E32",
            "0x05F70A6D46fd0E7ce48Ca33d02178d74c8F7553E",
            "0x066A9C237f97b30f2c6181F3181E26BDF5F6A686",
            "0x06A2828F5Fb78BfaEC8E6bA55139AE5E7a7bdB1c",
            "0x06d4e92f8b398184405b2E7B229524F84Bc6815A",
            "0x06Eaf65c89eDe36F0c2410389dE4F8fBa8B0DeE6",
            "0x0748b8B2DA31002f6E37aa66Ce73FAd0d8587D3C",
            "0x07AD76F4049210722f12c996e86169Da55f3B681",
            "0x07f38eFD9acda49899371c0f8518E7b88806F158",
            "0x08B5bfEB412443cfc54E38656Ae88f6bDDe4920f",
            "0x093e94741A8F96Bf44Ec92d5F0E464B109242138",
            "0x09a07b4AacFf982e6Fb96E57E30D0264687a8D16",
            "0x09Eb3440269272cDAA26f4bCDDc001eEca2Ccc13",
            "0x09f2a73d83DEb3817eE2f6fcC3C64D96E74BEf83",
            "0x0a37bBc41356B97eeE9CA6EC51Cd142D29A90919",
            "0x0A6268F3ba77252acC9292ddE194e4BB7fb6aaAA",
            "0x0AA98D3CdC335daCF4778E4DA043172832E1b045",
            "0x0aF2292f766eBf5f6F5122aE5bD301B9B6F62CA9",
            "0x0bda572BbFe30901de6A203546595A5324480cE0",
            "0x0bE1E4C1a5915DD1864fa6709A9423b7F9930890",
            "0x0c19bdd940a42Fb183081712Ab666dcE3bb695d2",
            "0x0c542670F1aF3518FD03c5F1b916Cd21a2C92961",
            "0x0c6dD9edd0D92c4Cfeed734eEedD6Bf8b7fAf489",
            "0x0C9dc3e0a2313E8618044B5C23fb1eA13ed90bd8",
            "0x0cEb7ac7D4EDe1a3120A91862dB20FeF3d56beeB",
            "0x0cFa01a8c2D7EA1b18f8c9929660dd79d7A283b5",
            "0x0cFa01a8c2D7EA1b18f8c9929660dd79d7A283b5",
            "0x0d3B30EE112be013cA66f32957574E24dc7BF79F",
            "0x0Da48a04657f0C2564C8D9FD46cDb1113e61cED2",
            "0x0dEeb0B8d71e39024b05853594D35150e9D0BB6e",
            "0x0e47e8E834f19946D85F1bbC770Ab0FA4dFAa5AC",
            "0x0e93545Edad0Ba8884bCEe70618c3D8D4D73d5B4",
            "0x0eFFDc5948719836da1EAF5CA5776060E36609AF",
            "0x0F212042347bd15210C66c01a3109c3157f2A12A",
            "0x0F34E9EC6971eBb89EbAB75e9fd194ac6295a194",
            "0x0F4c53E77525643693086d4785D2a285d14254E5",
            "0x0F615319D7CeeD5801faF6b13C9034DE9223a3eC",
            "0x0f7510251429BEd9826A9c3A748eb807890e0b58",
            "0x0F952A6502a6A59650018e484d638f1433aEa8f5",
            "0x103246339988c3A3eC32086A179d6D6b8dE34c4F",
            "0x1117382C910DD3d09C6d099a2BA7F887D02C744c",
            "0x11A63c41400661763e9C2C6Dd1DE5960a931fccE",
            "0x11A9c9a267FE4DB16f269b79ec8f879dffdce7B9",
            "0x11ca77a7ff3a14d992E70bf042f056485a40A4A6",
            "0x121B3241e6989fC237EeE8898eC4010E56E6D001",
            "0x12569E01f1F8d64AC0367B5ECA6948EABa5D97e2",
            "0x125E51e068b4a8c850d281f97fBe40CEf4014900",
            "0x126B9489FB9c9BA88DcBEa78AB476b8F910F6D6e",
            "0x12db451A69dE10aE4B2Ae0CC14776E6c041fEA74",
            "0x13436D53D1e26b49Dcabe072f4B6cd3622D9917e",
            "0x13547DdC339cBF22a5cb7562B3FDFcAD1BEDf84b",
            "0x136e22b33Ac697Bd7cB5947dbe4323d8dD6a23cA",
            "0x137d18b8f940b89d39bF9d0b69F1A0F6AB43f473",
            "0x13D911B6d44Bda3A857B001E797D6EB3Ae6b56d8",
            "0x141082BeBFe273451132F87BA3988F9Bf9E1bD08",
            "0x1524daC21cba8EB8CEfcfA331B13bB899540eab4",
            "0x159B787ECdf7A9cad0e50483483EFa127b35e930",
            "0x15E9E61871AE5aAF73acFc11B55B0aB4DA95406c",
            "0x1634DFf73e320d2fab02566C646Aa78b2553462d",
            "0x165c135B7aE5081321BfA475C01560efE728966F",
            "0x16f58a4042a03c344b9e67ed9ab23d70b9086608",
            "0x16f7a4bB3327B561C64D9694a183cf66cf47C765",
            "0x172FC45Cff67A60b1f421842285e5E38ecBbDafE",
            "0x17923BAFc3B42154C158eaEA7602cdD9Ba77409a",
            "0x1795011eA0D47f3Dbd757B77fDAa3F0366208237",
            "0x17BA112F7d096Cf0d134eBDE25C929c226cf103F",
            "0x17ceDdA24ce320f5A9Eb1d1223F92EDad5294eFe",
            "0x18cf8fB20a251742c4d06DD877Aa2CB01475731e",
            "0x18F8B9f50A131b366471b503729B5729bc7A2059",
            "0x19C991E56D7b1c8a728543C779527174C3c57819",
            "0x19cA6950Bcbc646c799Bf5ce0c91D8002A042209",
            "0x1A37a10F6325e4002ddcB287ba1AF4472746f76E",
            "0x1a47Ef7e41E3ac6e7f9612F697E69F8D0D9F0249",
            "0x1A5fB148e130922dE0f18D7af904eFB4767dfcfe",
            "0x1b48012465eD4b770Ce11AB18aE1e701E6DfaF58",
            "0x1b8D17Eb56c7C135174AC9ABaA95780B9B0Cc782",
            "0x1b8D17Eb56c7C135174AC9ABaA95780B9B0Cc782",
            "0x1c3a15d75bF8f82EDB9970bF6a93fb32109e8720",
            "0x1C6D1B778248238ce3ABCD5f45eab46f8272A176",
            "0x1c6dD7bA8860f10f6c14CB217c647B80389A9C2d",
            "0x1cA8ba8a8Fbc9Df50a5116b7eac81a0c6a5e7D7C",
            "0x1cCd3ce8aB0F3fd877af46B3F399E92C89edEf46",
            "0x1CF0e3c918fBc16527cBAce7F1C118c0Bee24fFf",
            "0x1d17115fe8e20d175005894B0759C8ca5e994dd7",
            "0x1D303D7E60fb50D3Fbe585953cfaBc7CEB71BFE9",
            "0x1d5A112Df055a18Ebd22E87CdEF061350949AD29",
            "0x1dA6A7F98b14DC4E5509947Ab5A576906D183Ad4",
            "0x1Da9c59779a410AA2693DF72ec96D224cDC47E9D",
            "0x1E7f6843F45Db0961d9A057604Ec18fbE85edcDB",
            "0x1E93e03cb1798B853262A2b7cA19D7ae642bC8B7",
            "0x1f2a1Bd53e510b6FaD00cb6601210E1202Ed3f86",
            "0x1F3A0dd591B51Ae6a67415E147c7a25437B54501",
            "0x1Fa0c42a65B51ABdd384C1bba97992CA478DF4e7",
            "0x1Fc4BC3B9cca5A9b86C8D5f6fa592aF999561F28",
            "0x1FdB896Ecb2faB34f9b7cfb1e0ffc4B54227B090",
            "0x1Fe03D0801b3047456efA65Ad697f83929dF746e",
            "0x200FDaa83581E6D493FdDD11aEd3dA3298e1c2e2",
            "0x2011A1013505C0bdd3F44ffc32AE4C84A108e1b8",
            "0x2011A1013505C0bdd3F44ffc32AE4C84A108e1b8",
            "0x20273890e90c7ed3cd1607f8ac69540152e0be63",
            "0x203d75961405B10e19E5a1d5277FD67a8d1e2a6e",
            "0x209d512a0f7908153B9084685B9176Bc8aa8A693",
            "0x20a85Ee75AAba83E4df0E6907508ceFb27a2E890",
            "0x20C24f1Cf945b9d5924028987638053F15dc28C6",
            "0x21BD4a0C3C694C36B6115F4e292fA6aA203f0476",
            "0x21BD4a0C3C694C36B6115F4e292fA6aA203f0476",
            "0x21ec900D36dDAB539C6c1b92e620040B61536769",
            "0x2238eaE30C1DB5778E3f70Bf704901F81bd4738A",
            "0x23Ee92b61b35Dd0E749722E9320f6DE41073c7BD",
            "0x23f41C82bEccC9EFeE0a11FbdA273dbdB5E3e14A",
            "0x240471181FF5F40E51Ba3F44994Cb0C844f7bDFB",
            "0x24192c81D1a8bC30e037E67EAaDDB59D199713a4",
            "0x24907C58e080F2a9d1f31F25d555aa3d5A5E3419",
            "0x24907C58e080F2a9d1f31F25d555aa3d5A5E3419",
            "0x250103C32239Dad3F31D121d75Da22353C6FF429",
            "0x252409655238Bde5eF79279dF2e96cCA6aA58E41",
            "0x25752c333e544a13A2b4887b5F5488817c28f2c9",
            "0x26136e1f86Aa285f1D180f6206256dfD3E5Bad5e",
            "0x266193866dd3F9d6b6568989e0212bDfc2A8E4cD",
            "0x26769a7708385161377B738a702174af339Ca2F3",
            "0x26bEaDBAF2F7FDBE242AD37A801E97b86B22b217",
            "0x272A02807725aF47bC7Bd80358a1CE6516D48955",
            "0x2734c449d1a1778d2d2693b9084b0E1fFc48331c",
            "0x2749Af4bef7c7042D37DEeFA7978Dc325f461eb0",
            "0x2749Af4bef7c7042D37DEeFA7978Dc325f461eb0",
            "0x277367A5b07A67065e3f6E2057cD6924C5b2F45A",
            "0x278d9e9efa37b551ebcf5125abedc44501cce66f",
            "0x278d9e9efa37b551ebcf5125abedc44501cce66f",
            "0x27Adf7e0Ba3b31A5583F929DC7DB8fF99c787b79",
            "0x2881fDf7e15D3664BeDCFb79B4775A89ED7Fc122",
            "0x291E3c13040C55607E77507FDD350fa927710101",
            "0x294D0baCC6AB2c72D81885eB7abA3099609C2d38",
            "0x29C116D610718E91EA07a7d12321aa9c9C5DE32b",
            "0x29C116D610718E91EA07a7d12321aa9c9C5DE32b",
            "0x29Ce17DC989D316C183EADe3932DcC2f25af273A",
            "0x29E80B2A0325E6c6eEA4bCD2e8dF0CF7b46063B9",
            "0x2a381a41627De73C9285DE8f5b74791aD18Bd292",
            "0x2aa7b44b2EFb8A0eb9cdFD13207Ff2EEE93bfB9C",
            "0x2ab8B8a886f9FE7477b2C377e8E21BE8073B1F94",
            "0x2Be908F0C1B7dF4680D6C1Ba61329C792d162DA5",
            "0x2C1db30b007C384C759C5C4f4817c557B681Fc69",
            "0x2C613048524a633867b0D97Bb12a33876b2E7677",
            "0x2C867F924595Ea94A857dEe43dcacc7BC29d2dA7",
            "0x2cf8f32371888b56c1f96f5e846b4305e62d8b23",
            "0x2D07389477C2C477df4934c545E8892C990B7C98",
            "0x2D141351B05d8b86736065E1C03FeC7a719E685E",
            "0x2D6Dc99b4e9Db822efEf1d0A1C514Efb0FeE7F43",
            "0x2d8b4D0e7DE9fC2b2B98f94B686085C1f5F42364",
            "0x2Da791359933011B4F74042a241Fbbf09F6CBcAB",
            "0x2dF5A97C2AcE6e2dB08CEA422228B3E480eEbb86",
            "0x2df7C307F9B62d7Ec218A041249C9CA6c2947523",
            "0x2e2F8Fd4122F26ee3E658659927524d31fbfa7B6",
            "0x2EDaCa30FcBA1Cd60bE4a43bF410e39cf5cD1B74",
            "0x2f14b0e0AaC7dd257A50c85A61e3ce03A3697B10",
            "0x2f4597F967F9038d0D7dff872B5E82aF28e84299",
            "0x2f8d5bdA4F90aB8b3064D05b8668500Dd23844f3",
            "0x2f8d5bdA4F90aB8b3064D05b8668500Dd23844f3",
            "0x2Fd268b52b6952Ea99B5Fa203ED1d45C3b61d77f",
            "0x301de8793757599D306bbC38b638292670cF9289",
            "0x30C13cA4632a3165f9486ebfb69BE26E52e91cAb",
            "0x30d9C46363d5BE604BDfCA017D138b4E363C8A1B",
            "0x30DB9Bdeb3F3d118b205d4D204418acC29BD9520",
            "0x3166bb4db9dC598d136B385B8EeE6bB5457b8660",
            "0x316721C88f9C1a287d42298533DaFAeC181c6927",
            "0x31B42e98B165598f029548Cf44432a8978a37c35",
            "0x31F7f4Fe1bce32a99b99a616D81AFeFeC53F1FcB",
            "0x323Aac7c3140f5Ba1CB04D36f7456437C7625061",
            "0x32E2a213D7C5407411a081FB14E31edb754cfE2f",
            "0x330AA0a042347313B68Be4CB629323488CF19D20",
            "0x330f28c48b11256eb75138d2376ccaa0923b30d7",
            "0x33406da992f070FAC68267f80feB11271223E8b3",
            "0x33B507FbB0Fb83D20759b8a32DbAaf3Db4BC5a50",
            "0x33Ee8470cd82145860f6DFf2Cdde7E8D7B6c3C2C",
            "0x3406dC6A8e01Eefd44C8623AaB704Bb60e074743",
            "0x344764e6496250915c80f71A594Ca89968E6d6Ba",
            "0x34e4Abcc76f600BeBbc3968969eE6026F3d51887",
            "0x34f7018ce1d29c46f6537ce678adb85a327640b7",
            "0x352AE28c1BfF4490840b93b79b13dA6554eeAB40",
            "0x35a06466de7b641E98511bC7D2e09bDf2550B2D3",
            "0x36027faAE04A77D95F8C8Dc10F2215b40bc3610B",
            "0x364e9866CC5C11A778f9708c0fa7D9Bd47421307",
            "0x36B168073Bb3A8CC8969fD67827028C5D011aCEC",
            "0x36eC20aF99A7C79Ae56b9f7596fb3efFc2967B3a",
            "0x373FC2d830B2fcF7731F42Ab9D0D89E552da6ccB",
            "0x37660b87525559598c053f0f5b4c93C44Ec35E13",
            "0x37c4F6dd62722903285308225E645D1CE379f827",
            "0x3808fD269346976fDb5753ba25761899EAaA8C0A",
            "0x381163CB0ca3a29FBD43FC1CAE0253EF9d50E7E3",
            "0x386D63939cdd398454961C1fF03012000fCb6b7d",
            "0x387298eF626E27738fB76430c4a0BfEfa8A5b1eF",
            "0x389cED935e3E4AeaFbeF6e890F9f6D6c36ecdD38",
            "0x38b75378A83d4A3d91d4273a3c98d973dfBcdb2c",
            "0x3929C05b12FbA082a44448369b6d7541733661C3",
            "0x392D149E30Bb65a4AbD26e352dEe9dE6c6278Eb0",
            "0x39576816593A973b71d59DCfbf7F73561e2265b3",
            "0x398Dd3E71D4D5c9e6D2aFD0668a99D4A7B74b90e",
            "0x3998e8De5fC37131b5D27eB887DdEb532945EC73",
            "0x39B55aBfdE1BAE089bBA0BA106DFc95A9d6a20d2",
            "0x39FdDA951a1Ffd1d6710F28BbA9941cDBbb62198",
            "0x3A13646cf7Fac5a566d76B048deD85BAB2F1E075",
            "0x3A1f91c4FB88e69452b2da0fad4A0dC3Ea5FA25D",
            "0x3a692FC43057222e8644cbbC850243929Cf9ef0d",
            "0x3b356C8753388ef0E5f979ACdB8f40bA24dbDE6A",
            "0x3b8e57fe98CD8EcCeBa27EBf28887d2b3cEb6f00",
            "0x3bf09156CC0f63f9Ccb72EdceC2Ae30A3fA474ad",
            "0x3c12bA2B6D6a1f1Bc754315d30eBd65F954A7530",
            "0x3c2F3C4Ba3bbF23c3E163A7E9396fee60043032F",
            "0x3C43De04B1c8fA340ed777853994406F96EA1E49",
            "0x3c52B4fA783C9670DCd52D34A2B5f216d30A3b4e",
            "0x3c70255463a9d878842cb0FC808dccF4e92669FA",
            "0x3c80dF0A3050e2741630D80dD6E3AF5611e3685a",
            "0x3Ca701AA98Ebb0BB22792EC547d79179F1d119f1",
            "0x3d2f2b0c18f7D2FA2A4aE1fE626D3A0fF58C58Da",
            "0x3D6F6268b62c401A0e417A853098d097Cac78F2e",
            "0x3e76a43C658F34FE5EfC665D7546845e15388A80",
            "0x3e836617e1Ccb02f656DDF258194407C7c5A6F3D",
            "0x3eA3aAB1eA2Dc26be63c91f8105EF1B2Eb093D57",
            "0x3EA5Faf6b9A05876128B50b52db6f2C25b30b32b",
            "0x3f0B17679cBBf848F9f198Cd0Cf0D1462bFCFaBB",
            "0x3f4373afdde3d7de3ac433acc7de685338c3980e",
            "0x3fcf7AE03C609bcdF7f1118940CbD13709a62527",
            "0x3Fde0C641eb5bE5b63bbCea98d7D28da4cf12CD7",
            "0x3Fde0C641eb5bE5b63bbCea98d7D28da4cf12CD7",
            "0x4033f04E652AFa01E5e99ab59d28e0927d372e17",
            "0x4068887045Db5b1797aF839398cBf2355Bb55C86",
            "0x40F9a53aE2afB683FEf478E3FA0a03A47BCfBC8C",
            "0x41338D84A3e14d506499aBEb455d749339E3FF5c",
            "0x4162eA18d68e2e385a9e39325aeFFCebb70f42D6",
            "0x4300e4546128F7Ce43b8C312032367b0136Ac76D",
            "0x4455cA1e97252A3912b0046941200D7f9Bad262C",
            "0x4455cA1e97252A3912b0046941200D7f9Bad262C",
            "0x445934820d319b9F26cD7E7675c3184C0E2013FD",
            "0x4488708a72a335D64a3a8b62ccDe6F15D50FA9F2",
            "0x44D5AA8BFa258dEDD2cFA9f6f9560eAe48ACDbfE",
            "0x457427071938620ffE0943E16f56bd896C00Bf4a",
            "0x45F372BF9cD775eb1292d4973113e730c2B2aEb9",
            "0x464c4587A393a609E6154088e180F6D1490eA55D",
            "0x469264AfE93730d82e386e72B24cb1F736f164Ef",
            "0x46f8ff21273969D08Ec843ED7179874c6e8Ee868",
            "0x46FcD49BCCDF9d1EE6A985E0Cff9F10520cFba46",
            "0x46fF536940aED736E806C2E5FC1Afe9ece395Df6",
            "0x473260397aA6bC1eAbD98d069f1329cc7394FadF",
            "0x481Bb09E349120454C78d8e67De1DEA87Ec94603",
            "0x487bA5971c141958e1eD202bA5c327050E59cb91",
            "0x48F4efc8EaA90C747E7859216dA14149fFd31eA2",
            "0x497fE20C94D4Ba9247582462d6dcB945B160Fd20",
            "0x49a0A75E6fDA0710921ad00034D9e42B12CAaFC9",
            "0x4a8a4b5F204BEF5eC282C471d51DF9600919d317",
            "0x4ab6c0b08F33935189d9a664715a2479a61De4fa",
            "0x4Ae43208A4429c1D115E4F36A45D51DEce635Aee",
            "0x4aF3A57a6CE3FC4Adc593A604c06732B8358F598",
            "0x4B2e12B29c806F73deca91A5435F67533741cBd4",
            "0x4Bb0a44B3CB404470A7806718BF591b587D6bef0",
            "0x4c37DAC30498684B35AEeEb3dA0CA9F6379Af489",
            "0x4C61a5F7eEde0155C116520F5E1a3e16346454aD",
            "0x4C8a0C8056A3AD47f0FEfBE61CE16b623077d238",
            "0x4cB259dAff37CF591630aD472d4D0Eb30f030c79",
            "0x4CcBC96A926Be740A09B1b7aE7C3cf6F470c07C6",
            "0x4D0e8f3b6E31394ddD52991b765C8E03918Bd98B",
            "0x4d63A54C8B8dE664451bb7eBcB4A4883B5CaE64b",
            "0x4d76FA0F6c2E956E68d3C8a8F3Dc16b24B83909C",
            "0x4D979c18A2ed18EEb52054bFC32C6C0946781818",
            "0x4DA562e3bfaAEF14375A99AC7B6d9eF009E17659",
            "0x4E080DD8F496f80CA25FF0FFAc6EA5785dcd8588",
            "0x4E5829056b72E339739DA736F70904264f5a1013",
            "0x4f319d0923054C768d86c22c9f0Cc6068d2961Cd",
            "0x500bb12d7d453c8a8d16b4167946f11c98f5aa5e",
            "0x50b9E7576E2ee7DbBECb7Afd17458f95456a0967",
            "0x50E7F1A74EED2c1eE14Ef31326C9a34af7dFE7B5",
            "0x51764790B30b49358a3b2e6f30Ad77484b885b90",
            "0x51c73815bcBf2ABF23F015bf0592f864fD2266E1",
            "0x526Dc23263a5ed4EC20b0944AC1951C348199Ef3",
            "0x52e75277ec17b2eDCf56026277f370EF47bA6F6A",
            "0x5398C6c2F7a57BE6C12137B672888714819511ab",
            "0x53E0B85a10d1DB2d819179A32E71b7167216e332",
            "0x5465558C4Ad8E3a7d3C170d5356C417B703dEe86",
            "0x54BC0Cf4c57f70602909259a3eb2B267cB758925",
            "0x54c23E1E5D2d17fAc5bf7B64F0Dd026ddEb8A769",
            "0x556bAd63d0F602601AE1DeF52b609Eb88b65159C",
            "0x55c6794647b9208F69413b8E0ABfFF00f4023ca4",
            "0x562b519f08b7cA52F5Fa5755e0923637d4602742",
            "0x56f210974e0Ac548cF75c6034f1C0aa515c818df",
            "0x571d949cb506E11969Af92E4693812960b8f4882",
            "0x5744aEb6dabC2dC67eEbAE63b1991AbcCd248D83",
            "0x57ee4c0e6fa7BC04027fd9a62dC9A8759EcFc4c3",
            "0x57f8331C0930E34794268ABa1CBaD642e3db7fBD",
            "0x5819Ee729ec366Ce1e4C681A1d23DE2C966CddA5",
            "0x58D00cDCd471bA127f2944414cc2Cb2E5650dE79",
            "0x58d7ec977D35E03E69DA39D4A6DcbC9f09bdbE6A",
            "0x58f67F7fD869896dcc59Ea2aBa0c1C69F52e32D4",
            "0x59877d2ae955ef54a6c99a22357bfc00815181f0",
            "0x59a6F585817e8587FB1360Aa1A2475fF599304ba",
            "0x59B12B7ECE14dDF563bF36e10F759b8045269204",
            "0x59Baf1c9CA1919acC022091C0fe1Bf9D52c18AD8",
            "0x59df5A019b8d8f3FA4360e1A92f7827919181e56",
            "0x5A3404A3358EDAd5E499E59e11aaA20AD0249028",
            "0x5ad0A8b8C63799B1b0C1617D5dc587b92E1692cD",
            "0x5B2BE2A4A0A9BCAC9e40fe523d3AdB59e5E9f16d",
            "0x5b94520b07f7667c898f6dB153F25fC8d2375025",
            "0x5bA1cC0E6d36c4ff4d2fdF1C83f8B250df129b3f",
            "0x5bd40D2e4Ba55d06780252f8935668B31d72CD62",
            "0x5BdeD102f78d3228480e60a775EaB13695109ee3",
            "0x5c344BA4ED12b0Eb0632199D4cBE91DeA12f7e4E",
            "0x5c4231f247FC3935D3b1c3AF43B05f6b2ccDbe76",
            "0x5d0465f641aD1efFDFEf661e7FD100c023d070F4",
            "0x5D0716f284ed3e53f478b3Ec9B2936cF5b67BAc7",
            "0x5d547DA6325c086CD8d767A8d42Ef6f4BF5e43d0",
            "0x5D8c4Ea57b8607cE3D3E220574e291Ac98797e9A",
            "0x5dac350982c4380fc39b99417b7334C2d5365436",
            "0x5de00107e45AeAec663F463D5d2259D8588053F6",
            "0x5e05D922Ba9f9E4D62f289aDA4633836A4eB9377",
            "0x5E75d5cbd2bBF427697EF1E8ad7ea019A5049757",
            "0x5eAB685a66dB107bC228dA7eB09bB82d84CE8C97",
            "0x5Ef84C9204c2888DB12fc2B93F9a352c7e597a37",
            "0x5F1b2064c6B42C8f144C3949C30e8D5A4c6EA15E",
            "0x5F1F6372b7D8d01BFBd4B2332a2660b30f52B9af",
            "0x5F1F6372b7D8d01BFBd4B2332a2660b30f52B9af",
            "0x6041B8938ac480FDc2F1841Ef88D076E2183d0dF",
            "0x605C1445068CBCD706f329309F3831b1681E1052",
            "0x6070752c0fCfc01dF5260AC4aD5baDDB0B849a73",
            "0x60916B17F8B0B9194baa5eCA43b7E1583b99A714",
            "0x612952a8D811B3Cd5626eBc748d5eB835Fcf724B",
            "0x61B5160F945B843A4Fa66E3f0F9392e487Cb09d7",
            "0x620dfe58e7cF60Ef082d45c6c40Bf3cb2386Dff7",
            "0x624A1c72f40C21D3FBA0E838cafcfc0856E49175",
            "0x6298eC445f7A46Fa95ae37975a8D90672c83fecC",
            "0x639c0a8DF54E3402607Cb4df7a00D4C0b2457476",
            "0x63e6f7cc98820df50e2F9E0D4Eb8347F8143F5c1",
            "0x640919D5eea1e39Da26c2c7209543FF365718204",
            "0x643d8F4ee63A81054F762FE70FaBfb5C0a4d709b",
            "0x645990467105162Ca1a74b45b800b3BEcfD405e9",
            "0x64Af0FEa7146B28E29E2C87737d008785163047d",
            "0x64E55C710550A89D00F39E38dFd07548b51B4943",
            "0x65A20e69246D47dC201590222A15F459ad886409",
            "0x661d3005506AEA3DEf4422606b1A31be9cef1d80",
            "0x6626AA9EaA9C35E02997a9E59061bC848028810A",
            "0x6651788AFCcFbf06cDB32aDFcb9f6390cad18d4A",
            "0x66770EcbA3542C429a9D46bF9182Eb21829d076A",
            "0x669dd7F700AB3FFC7a91fcb184d3d838FB7f484C",
            "0x669dd7F700AB3FFC7a91fcb184d3d838FB7f484C",
            "0x66E3Ab2209197520294201ca19A11061380c6acF",
            "0x67b88bD645bB8B477C77fe9F78e08fFbd265cD38",
            "0x67D210B9A39254803A02c78C91248b8a8Be01d19",
            "0x67e2967Ff9fd5d48F5a96d77f8dfE9C6EA48f984",
            "0x68014063515d0281593c7aaA4875Bd625Cf2Ad93",
            "0x682C115E0784db5255b800b912cd1C062Bf93f4d",
            "0x68681c5Bf1f1B0F4617c4D68e015D395FA0A0bd2",
            "0x697c164D772d0F02A0244026936c8b715f6eaa54",
            "0x6a4FD6eb1a79C00BeFdf54Ac1b2424F2dC0D083D",
            "0x6A5dE0939Eca7D5F56765Cf4a7a9c037934Fb7cb",
            "0x6a70dBAE32970469c18B90D47716bFbDD2Df59F8",
            "0x6B7bc6c089EC592F3774E590d43eB20904Dc98b6",
            "0x6c04253dE5092bB2F696b662E8c2F01344141e05",
            "0x6c31bf87891128D6BB17F2b0291f2D30be88D850",
            "0x6c550fbaF83c799Fc141bbD68B7224cDe6Cd991C",
            "0x6c9955D77F187b1D5eD9a9E74D9eCBf6D890Bc83",
            "0x6ca82aEc214F0f3D18123d7D4869d42d97d96026",
            "0x6CB48953112c6d2E3Edc1a2b6be13A19d4DEC050",
            "0x6Cba252efdc43881e9a103d473F70F1BcEE75582",
            "0x6Ce512aFaB743BDa0f71C6CaAaC1f9f8a854FdCb",
            "0x6d0f47a99d064B15C733A5370279dcd7986Ee3f5",
            "0x6d14FEe3d3EAA9dF21F9B7011226AAA5A33F702a",
            "0x6D1912dc58B97D81Ad9babE58fb59a6C339Ba823",
            "0x6d4678D0B9E4e1D1E025aC30f0BADC3871B96183",
            "0x6d8610a39D293E9397103f95a3E7562b8d1BE186",
            "0x6d89539129889eA10f36A42bd96f5b8a7C4D6490",
            "0x6Dedc1d5a9B5bA7d36e0BdD696aC3110a61729A0",
            "0x6E028c91a7FEf1C020a064837E4979d92e278DEc",
            "0x6E939d8983FCf0DF8c71dB2B8463d726b6BeF0d2",
            "0x6F241e4d5ab1A133187d893EcACc07a14a5dA7D0",
            "0x6FE150e29E4D560d4a1f40A46C2C75D3E4fFd163",
            "0x6fefF91951bB5D3438c37f0Ad6f9cBb3900808Ff",
            "0x6fFDbcdc228739F10CC99949a9575792941c3C4B",
            "0x7003b34F7d91093bc587Bb8C8806b6Cf64d00282",
            "0x701193aEB6183389F2993dc81c5231751fF5c6bA",
            "0x7071E520Af8fa445579E934c145b0d96e5136fF4",
            "0x70b28Ae80A7Dd83c9b14840b25B3a6a85a91703b",
            "0x712Fb434a285644345629F077814Ff6583Ffcc90",
            "0x7173b1be97B35F2F07AE7D11CeB84A6088200B69",
            "0x720579e98ce71D9cFac9AB371B52D8Dcd483889A",
            "0x7206C7D6620EbD52ed29976351fC0ce09c3d5462",
            "0x7213Ca35e0Ea016Af71D299B43A93cE4ddaeF0a2",
            "0x722Aa79592c0Bf7b5d674bEC246490b8D1060687",
            "0x72d47083AA4593909535b19bbea290c495237226",
            "0x72E87b76F25f70F73579a8407B32907aF19e3cC2",
            "0x72E87b76F25f70F73579a8407B32907aF19e3cC2",
            "0x733c660DB1007e1e2115177ee9582E1065325DeC",
            "0x7355fE1fA4b61c6E2b76448f92f55A349c022E2A",
            "0x73f25834989E6f42E6776792C694ecE16be13b10",
            "0x742B5F5FD0c3D32cA23D0bcE4095Ca652723A549",
            "0x746849550373B814dfD93D8fc2a9D37CbC226bB8",
            "0x74903e0825Ca4cFcfF6D9D7d9E1E4379a6bDF064",
            "0x74BB89fdac6Af121C63Be8D3Ff77b6640a55525D",
            "0x74e8D326d609f5632Cec23BD68434CDc125DCEE4",
            "0x74f2B23AAd780E4d0030dBCF70201c15b4Ef2504",
            "0x74f522F3318165482F99b37f404f985e05e3dDef",
            "0x762fB164CA35B78d6e5F8bA66C97B50115ef2113",
            "0x7674586111ec6327C54FcDE0bCfaF43384E1FC7e",
            "0x76b44b78701e599c71258C2514Cd2f996eBe2ab4",
            "0x76D0AD6863b627F5786E7C6d17BC67426A9a2787",
            "0x7701cC2986207232b88e88DFDd4E1BE18B5381b9",
            "0x771d7CdF8A7aaDfAD9A5c432d1dB1f51f7290208",
            "0x7733A8945AFD4Ac21262d60E23f8cAb30dbC20B4",
            "0x7733A8945AFD4Ac21262d60E23f8cAb30dbC20B4",
            "0x776F56AF0a0daFf90CB3578c4b8Ab2a6C9367C6A",
            "0x7838A8721d82703DE585994baac3E2e0ECBC0aC8",
            "0x78616Db12462D2236E4ce8F5861c299bc85a087d",
            "0x788a6ABa8E7366eC840c6f2cf78b4D1FDeBE8F0D",
            "0x78B61a91140879E2A43D991A3a0266b55be3DADD",
            "0x78d13A345B7987fEdbC54Ead3E6f8d75CE668bd3",
            "0x78E9F69edF35Bf133738B6d27D0D01ceB07B7414",
            "0x78f3eB9C5cD900D992CF707FA23cAB480855772D",
            "0x79E1055c173e96Dae7e44CF268E459F2c9225B99",
            "0x79E2b1CA67fCE93abAa30C8183fFD1f89b3A6dC9",
            "0x7A1324235b4bB607B64b8e44937bA56731Ec6295",
            "0x7a35d00A0Ccf669D42f788b77116E36a92b2c2dE",
            "0x7A76c76D6E2e1263eA8e143aCb5aA599486d1573",
            "0x7A8fAB4BAe5BC903B65885B6a802052961D7F7f8",
            "0x7Acb37231BF83dA3e46B215325f01943238cCF34",
            "0x7aeDe9cadafE2276bF6962D2C503AbBb21AE5A2b",
            "0x7b207d27FF26069E48EA631518a2E784a1460cB0",
            "0x7cC07FFdA27D53a7C8AD4dA7a127E77E605a979c",
            "0x7cC07FFdA27D53a7C8AD4dA7a127E77E605a979c",
            "0x7cC07FFdA27D53a7C8AD4dA7a127E77E605a979c",
            "0x7d3e3834Ddf4a3852eF85DB39Ebaf50B415aD3ed",
            "0x7D8Cc265a4a8fE960566346BD2F4729D5ee91bC8",
            "0x7e43b5b0ef35b51bc69D627AEEA3C54854F95F4E",
            "0x7e5C4d9B5E87f9584a96665d409f8D62A52CC918",
            "0x7E5f079d65F257cCb204851594d821Ef5007FD33",
            "0x7e6161bE6635393D9dDe356DE0Abd47885df5e2b",
            "0x7eF61cAcD0C785eAcDFe17649d1c5BcBA676a858",
            "0x7eF61cAcD0C785eAcDFe17649d1c5BcBA676a858",
            "0x7F0288687Fe60EAdAD97C2fcCF3294E95083c8d8",
            "0x7FD6CE56C531De03bee5488Ebf57281d6232F1e2",
            "0x808A0Da673daBb4aE72D804115Ca371312Fe87c9",
            "0x80Afa433Ac3F1A46c9F6ed79bec1B201a8e6d076",
            "0x80Ef0FF15e0E7c7F616A4E1149550d20c6B46A53",
            "0x8126cc58D2B3A7F6897686f34340793516524f8A",
            "0x8165Fa047598758C799b3201542590DC03dBfbC2",
            "0x817f0F493F9654857DEF706280AF2b2FBf2DAaa5",
            "0x81e3b1Dc883a74CD1e11a92FC1357d9CB9f40548",
            "0x8209A0f91fE84e756A624F079e51E9E29fDC252a",
            "0x820Ef4Cf00de7ce2ac2645326b98dBd27Ca16eB4",
            "0x823fE22579CC75593BA7E1CE2838d3a193EB7352",
            "0x8248B7b41CBF3BeA2dE34661FB46805ec56a5A12",
            "0x824E520aA1E328932fdE4Bf36Eab847399cd60D8",
            "0x82aE67f34698bb77e500116bd19d66e151495a0E",
            "0x8309CB44eEAdC38c0878C478EcB5a169A571b2FE",
            "0x835bBe0f99c15C2CB8FdF858868c1D3C52a50fa6",
            "0x8365236b8b29EBe2A67eE167E605cFb7f28bd393",
            "0x83656f67BeEa8F4Df00a5089Aa82b41Bc11cdCE9",
            "0x83860Af58eb657cC83880E8ed7bfCAC2863e6E7D",
            "0x83A8a2D305Fa4fF95683B11Da62e1c343aF5e79A",
            "0x841D5B5E5C856ED3B103f4c347d0659D4540F7fb",
            "0x849E0998e3276753bb3a90884480D7154e42Fb61",
            "0x850352b0C61aac1EFDe8c8a4d6C5a17f49e266f6",
            "0x85b826B5eB230D03Ce1BB41DED646909bF0c3F4E",
            "0x85bF0F7F6Fd85fa2772eeC17784CD92da671d1a2",
            "0x85e899765E45EAD6f144FCb3c27e4Ecc22A17b9B",
            "0x86045398B0188E304D95bB24695Aff88dD4A410f",
            "0x8632916c7F325dC821c969A215fA5241406a4a8C",
            "0x865A5C5Fb6B32E1F3fACF741e564B2f0bb251E47",
            "0x8662399A2B270227a6F49E910E984eF3dd43C18D",
            "0x8720B084Cf5A6E99b35Ba0fC45f848705D276D00",
            "0x872eab8A707Cf6ba69B4c2FB0F2C274998fEDe47",
            "0x87438f604Ef68bfcd7ae26F296f62098D8Bb1051",
            "0x87554f13162fa0aE9233B696dA667d2f6cDA0822",
            "0x8796F4771aDd7FA57a741A08A3bA361BeeEF5109",
            "0x87BD6713E6967A0aac10649BAc60216041Dcd13A",
            "0x87e485cB631d7616256076A9Cb64fFf5c7Baa468",
            "0x87e485cB631d7616256076A9Cb64fFf5c7Baa468",
            "0x88d19e08cd43bba5761c10c588b2a3d85c75041f",
            "0x8900D3425D81B0AD3b4f4db45B882BcE8C454E19",
            "0x895E3389b10Ff8e061d20c3b2d44f95548c3226b",
            "0x89D7653b9d8c3A6024032eA4094B16E24F1B7472",
            "0x89e1A971D1f62Df8CcDaCFb11954D8f1c81897eD",
            "0x89f2C064a1e1ee5e37DF0698Fc95F43DAAA2a43A",
            "0x8a14F51B8c44A686afA988DF32d995066c52d64d",
            "0x8A35AF9E0fC96b29758947c7cAc7A38E263dA171",
            "0x8a3F90eA371D278Ea3105F59fFfd638Da3b32261",
            "0x8a584636d8601ADC2b73b73Daf45D4fb0e881742",
            "0x8a5ad51A8F515597fd7818bA19A8414e14e07FFD",
            "0x8a5ad51A8F515597fd7818bA19A8414e14e07FFD",
            "0x8a94cC6Cf58d6318Cc7834a1195C85c013C08DB9",
            "0x8ad400C7A6db13159baE9c2bEa879501e981788D",
            "0x8AdF196Ea4E6d93e00b09DBB3Eeb32291556B16b",
            "0x8B095365E9831412147b5dC07e644dcF87325106",
            "0x8b9F74c62fC3Cf0D8099f3Fb6f4cF84aC836bDA6",
            "0x8be8f0Ec8547Dd725658bFE1119F730A3802ac8e",
            "0x8bEc2899Ec28Ab294bc19faf500008E5E7037cde",
            "0x8c093349CFB6172AC1494a75E42AF0514E3b3639",
            "0x8C274d4770FcA4119D357D8aEa16DA01D07487E6",
            "0x8c396319894fA956F582830E59F5e0eEe8c7A318",
            "0x8C5De05eC15fF9CC209Abb5dAcfBBCF0D71a88AB",
            "0x8Ce1fEf9a23Af24Bd1036c8550Ce7Db522B3E4D1",
            "0x8Ce1fEf9a23Af24Bd1036c8550Ce7Db522B3E4D1",
            "0x8D4D613834748F5e5eA30E8340028AF8726e9Bb2",
            "0x8e5F49AF0cB9E93b30d3650D079Cd8288b1b35fB",
            "0x8e5F49AF0cB9E93b30d3650D079Cd8288b1b35fB",
            "0x8Ee316524EE3b51438240e8cA99c4af365Bda6B8",
            "0x8Ef00b6aB619cF43527EAdD86395b44152922228",
            "0x8f458f7d25ad4fd8b9a3a701b3853e665d9108ff",
            "0x8f458f7d25AD4fD8B9a3a701b3853E665d9108FF",
            "0x8F5C213e58B7Fd57697Df9A6554fa9e0e3127750",
            "0x8F66c0c359B4546512BC8dca379B89Ac93008d97",
            "0x8F6C4Ea368B77E185a1dFD26924C84a95c55375b",
            "0x8FA06b4A67572f6E04722Efdc791b6262F787315",
            "0x905ebB12ccfE22f20F6CfdcC393F0F99F23f5440",
            "0x908141d3113E1701DBa8786d4012C90E5813313B",
            "0x90adEAA074b3961A5730b327e2f57aE8fd7865cf",
            "0x90eCb840360135722bc3CF8264eb7f0f642Cfb26",
            "0x9107b2cfc1b71625176B550bB84C9881272d4730",
            "0x912094461e12D3BBc7Dc4AF1740e69DC50e24D09",
            "0x917DB835Bf99e4edBce8c37AFe15B03B251ba41E",
            "0x9193F32B0995815C4Ff4A0111D85CFD83bb05247",
            "0x91A8cB88260f2FfA6c3e96Ba215Bf0e277E1F1bD",
            "0x91dF5104e197FF0A9AB256EDA6a68436361f51Fc",
            "0x921Ae88E3618189CA7d832D740dF2444FD0Df4c1",
            "0x9271307799Ee65E4b4544fD76Ec18035834eBEf0",
            "0x92e3aBaF9351aa3D5D9FBC8264774e11Ab32405f",
            "0x93107B05Ff39f13386eB5914DB1C89AA50a9686F",
            "0x93823D23e3eEbf844093C11cB0d0710C8c0c8eA4",
            "0x9394cDB927986dbE186d9D85892DA22a06B853AE",
            "0x93f9e715d0f216F3D281850D2cfB198ce149f294",
            "0x940E6267bbaC505d6b902472e8D2f367b4Ac0997",
            "0x9499e47d4B0d6e329F1Fbc851C977Dd7C563251E",
            "0x94D6CbEeD9341aab1AA4fdCd329703D357510a81",
            "0x94E01b3cBd349C751d07F19DA286d9287CB3F627",
            "0x9562D1A7360a06Bfa95419Ce8A8bdeec6d67253D",
            "0x95B69b070E0270499e5EC810Fd514EcF2B76F63E",
            "0x95E3d8a7973E6aB2666169139C5A759AAB9E540c",
            "0x972A6D9674A261a3C4BEcb2038B7E5D6ec9b09e9",
            "0x972A6D9674A261a3C4BEcb2038B7E5D6ec9b09e9",
            "0x977788B716d3Ad11Cd0709ee1611D7Bc1cd5721f",
            "0x97D670721d09F42f56aa6c3CF501F81D28CB4876",
            "0x97e5FEd154430029c881bF5485D44c5F1FB75c46",
            "0x97e5FEd154430029c881bF5485D44c5F1FB75c46",
            "0x98A2366cA08eD0a1AEcbC80Ad49Bf51a24213c0b",
            "0x9904bd54DA2D6682A673905b23cDF5481830c49D",
            "0x9904bd54DA2D6682A673905b23cDF5481830c49D",
            "0x9934cC465830967Ef8611BcE3c9E715014536D65",
            "0x995e7FC77F43343A23A90c65e4Ea84F7b54B24E9",
            "0x99a6b5d5c99566066F9A0A05905d7a23a4F368C8",
            "0x99fEBA78d43425515f307D89063c8651BD151DC8",
            "0x9a7bf91a97c79ff8d139dc06318e764fd6521d26",
            "0x9a8554d31EA0aA3D7cA4BE76340c5267308102A0",
            "0x9b4A60e2b9E4C1780370f8F9017278540586edFD",
            "0x9BfA48f5cE14D3e1b7609fA486A84a8a7FA56EBd",
            "0x9C57bE9Ea33018a8c898d47ED416F1d40543e5F7",
            "0x9C6F20AD5111F1f3B6F2d46Acc695A91976B5905",
            "0x9d092b94222d18D7d86AEf37f2067BA40a98562D",
            "0x9d3593099B73C253057d489B97dC04e379103E6f",
            "0x9D7Ca0e378d93A1f31D073f83039d5827A0fD5bF",
            "0x9d8D56a329e3D30a170c8D09B04863249942e50C",
            "0x9f40b4f609c03442D696132e53b5FB8e9C98D4ce",
            "0x9F836913343C0B46771206De4018Fcdd0D76A271",
            "0x9F94200F0cAfbE72Fe7DBc43C9D659182D041a8B",
            "0x9ff18dc645D519B90021F704df134844195d76f6",
            "0x9FF35c17c21e94E6EE97983557cDCA723e269aec",
            "0xA00530915d5b0685b307237Bc7a4feC5ECc88ff8",
            "0xa038c03fFC4Aa4a55A961060CffED8665dC01BC3",
            "0xa0a7b66706b7f5c178AE49486a1C98B32670C038",
            "0xa10C1FcbE6E6C27E1830f42F364fE175fEF49d3D",
            "0xa1c3dfA7e16b9C745D629182D5B4Da32e00204fc",
            "0xa1CFaE3082b21009495fAA57455Ee69A696dA4dD",
            "0xA27E9a2dc7f8Bb50e5eF1F29CA1575dc2E97CfC5",
            "0xA2dFA829C31B74c9Cdb073E5095C932060382841",
            "0xA2E8B5226d5Fc9c0fF1d653F8132e4Dd88019465",
            "0xA2f989ff2D2A50A6076FC366761f5015C2289A2A",
            "0xA30330970CEb84C710F76c2E6D64A77b1EEECBBD",
            "0xa33E5A36B6b69E866b3A1B048D67610d9e999056",
            "0xA366aE0E611DA5f3640Dc1eC4Bf881B957434371",
            "0xa37d698BC29A163A18d01Dc8db77f313eb98850B",
            "0xA403299f84fe4204fBCe07632b075E15A730F05A",
            "0xA44AcA78A014D9a00523dEa598c5864f3c5b8bf1",
            "0xa47467EfD942daCBf3b0D1d656bC512847e7f4e0",
            "0xa4c1D0E3774a8352B96390b6B3ac8C66BFc08a49",
            "0xA4c7318A6291D93A9950047513E017aEc7ccb9CE",
            "0xA5F6d896E8b4d29Ac6e5D8c4B26f8d2073Ac90aE",
            "0xA6065dA86288C0A79BCD9DeA123CB582335714A2",
            "0xa649549Ac6F152E254aedEbC3d64765247676380",
            "0xA64D37431B791770B23a43e48D157a08f7FBd229",
            "0xa6Feb695aC7475B0f07CBc6294E04849644a4641",
            "0xa7C1B3436A5931EAB86Af0c961be181BeF2448f4",
            "0xA7c444E1514E4398e72F3Df98DB2072c5aB358A4",
            "0xA8089e37B8B771571Ffa0e52d6aaCC7873B9793c",
            "0xA81dbB4C0A573C7C82D2419451FA0C8Bf67DB141",
            "0xa83e613818C75D132AB02e82abEcc1757BCa7eFC",
            "0xA897E28Fe8745897e9306458446E3C0E136AbD19",
            "0xa8c5Cee43C50C8327475D77AcB8336f0fBEcd98b",
            "0xa92F44dD563cc1F2E25A5FA979f2e5C1B95736A5",
            "0xA9D5F33F2AE1A72de7CCA9470F32EfD254948FBa",
            "0xAa74BE7b5Df3891fA88e383Db17A0D39965ABAf9",
            "0xAAF9481EC8DF84a3503542eA935F95479D9b3Be9",
            "0xaAfa89d68e8f2a7F1C8FcBe3bB5c657dbbf02668",
            "0xaAfa89d68e8f2a7F1C8FcBe3bB5c657dbbf02668",
            "0xaBA2407532c89B522f9075c7676E1fb94D664103",
            "0xabb893748F86B289E67D01231fda5015BE02Ab83",
            "0xabBFF35e351b3d3f40a84F8a09b19549BB063f10",
            "0xaBC514B0B262b5eEB80C866C16d9ce1B1f1c5F76",
            "0xAC3895789d836E9053808F16181BF554d1da5029",
            "0xAc91acC8d732F5B5E9374Fc9C42Efc4Ee6C63838",
            "0xAc91acC8d732F5B5E9374Fc9C42Efc4Ee6C63838",
            "0xad40D70d1D29d79b9AE3d92dE9902580CcDCb31f",
            "0xad52F76BdBEdB1B3dfe6448d4aaeAbCA8e09F7C8",
            "0xADe423Dc257436B8e983f92176D3F2519Faa1Fc9",
            "0xaDF6DC6A920f2db8174Ab1322ceC5317618c7C6F",
            "0xAE29d086B84032459a1923ecd986eD4fC653CfBC",
            "0xAE5966CF8cd369a0162aD2EB7325BCD0E488A681",
            "0xaeBBDEd04221C6d4D31EB5bfD64c68c238778d3D",
            "0xAEf4101B0f6Bd53F91380604DB1A9857da9C38e6",
            "0xaF1Cd05C8f3dcc0fC4cA9B1480C731e94125b292",
            "0xaF598AB200Bcf0bD35af67a44D588d94DfD227c6",
            "0xaf8e191994E4b1024257Becd94a22d097c2f958a",
            "0xAf9C01ccdDb9ff92Be4ac97939018313d924271B",
            "0xb0129c941eE1c9c8417A7c2bEf19B64571ad002E",
            "0xB02aC8d081489395f9f224D6ad1d26FbF7c82F8A",
            "0xb1527139e8033C914be5D6B101753933C178a3C4",
            "0xB17767Df8651C4530f24663396fD651F09359afA",
            "0xb1ed5f99016B9bfdc8c52c5be600D947433E8512",
            "0xB1f1EF4Ef29e1Ec5dbD6fF8463c4eF503FEf63D5",
            "0xb292A277b61341cf121FEd5A710B05E998bEC6B5",
            "0xb31415d10dc5072D816076eC5e064209e521cb59",
            "0xB316ee3b797Ab45300E7Ac743eae703ff400f8Ab",
            "0xB3419F794308aD4D14BC76e20dAD1cF7dC9337F9",
            "0xB35Bf9e65b8b95a08B45ef459FD62106998D04B9",
            "0xB3Aa500ac31c587Ab99c59786a891635068Ae64E",
            "0xb3DC6Ff7C5BB3f1Fe7b79DEF802048EaD10F8690",
            "0xB49E25DfF20B4393379F7D54f0106E0bb7c7b28D",
            "0xB49E25DfF20B4393379F7D54f0106E0bb7c7b28D",
            "0xB4b4F6865133F0a453CD4e47727eBa2CAE3855A3",
            "0xB4c48B85f1fc0BEaDaf80C37b7C94F102eC8Ca2F",
            "0xB4D03dA57197eD497Bf8Ca6592A2b51461d7514e",
            "0xb4E8BBACDD21f41112e14ff9B7684d15bCD536Ba",
            "0xb4E8BBACDD21f41112e14ff9B7684d15bCD536Ba",
            "0xB51e8246309194b4d626EdB841c54DAE932d4d14",
            "0xb585481A0221136aA5d72dD8822d1DB86c995F43",
            "0xb5909905fC5aA86813Ff5AeAaEA3B9952beE55d0",
            "0xb5b59D74d65361870FC4E43cFc8e498b4C5E285c",
            "0xb5e1b060bB1DBCF27860a9c123307F91529B7abC",
            "0xB60393b012E3e177f32eC1A05660e3c8AFc9266B",
            "0xB62B281882f448F0AC9CfF26e30746FC44FFe8C2",
            "0xb653961E0aa3e4fB19eb9043a728df0B17A030c7",
            "0xb72b905D535726252C26bA597116718255fa7Aa9",
            "0xB769577361A0930EB89Abc634B818ba06B55D38b",
            "0xB7e5A2fcE41196D74f200Cc7Ce926EF20a8Ff452",
            "0xB871cdCeA6C87216C90E1efB5131129F00488E25",
            "0xB90778D56Ad6A6912CbECf95cA4C88917B8C01A8",
            "0xB90778D56Ad6A6912CbECf95cA4C88917B8C01A8",
            "0xb93a056955095dF6f13793c12BCBdD9Dd0A3fA64",
            "0xb97E2b13F493A415cBB281c1c671376FEd61A000",
            "0xb9cb7F95139001470CD480D0eaeC83b5d8fd5dC2",
            "0xBA60185C5d10fc7b7a61326169a528D2605A33EA",
            "0xbAC1b29acB014AFab23Dca3B7Be6Fbe90256AB53",
            "0xBAe1fD559F4a1C046149808e5357902144Dec144",
            "0xbB1D5378682CAf779907dDD67dB324dc410b0468",
            "0xBB33c0b92D584E2B0001025fdC027768F738623d",
            "0xBbc6b65F6E25ADE2A97c8ff47f8adD5163849A60",
            "0xbC4E47E804D299e160604a283d3757d40440722a",
            "0xbC91A51Cd40E25174Aedb5fB556978F2487206a4",
            "0xbcb9d79b0161Ad3ea86e062352ea2865BCB38468",
            "0xBda188d3205C16C004CE983365eA4e890733A79A",
            "0xBdB7c9dc5011290Ef9db42beD34d13a28a981F0b",
            "0xbDd5D94E6463cF1683083A60774B38E7f3BC42B2",
            "0xBe1a2a86C38EA26D3cB7514EE28E90271421c91b",
            "0xbe387bDf287589a82D8811aed96B9c322529CfE0",
            "0xbeBcf96eEEd98D495F45407CE7017179738E3552",
            "0xBEbe0c09065c3221bC854a46AD537350523f2410",
            "0xbEcd1FF17116a055A76D59346D380482f4Ee7254",
            "0xbfb439E80b1f269F3a0e01e41A3f31e9427aCD2A",
            "0xC01134912ac5ee54CA51B765ce8E2d04D7075637",
            "0xC0d1dd7d632cB11D78c23B4a595981B5FFE9B043",
            "0xc0F009ba829F78ad22639615807f4ca1Dda62eb6",
            "0xc1C6C3744143c3f3A8573B74e527e58aA9Bf8302",
            "0xC1EC388FB98B84abeDAe8122Dd4d1cfC67f418E8",
            "0xc1F106c60e0435f1670cF463ac78872287765460",
            "0xC26A5b0798A3BD49086A673e9279e990b9f5971d",
            "0xc26b55eD3c5d0f465975417AD7F6154a164a809c",
            "0xc27BA52C493e291FA50a8e537142dF2140520F0b",
            "0xc2964561F6361cE6730A0cE4f733b7db35eE25ae",
            "0xc29d7FE198328A424B2113c91bcAA843D10e2c3c",
            "0xc2a224BEffCE5f7bA2f0AFB405a16242c4d1De02",
            "0xC2c0565339D01DD24d556De746eb8464cb9fB818",
            "0xc2e517e131a15e79875dc2b70f4FD1721924Fe13",
            "0xC3196297B10EAb9EE836Df6E52780512D9242620",
            "0xc33C12E94E8c8463365B413a60324fe9090c520D",
            "0xc347D6BdD1A4ddc267c96D30EFAD0c7181105D74",
            "0xc34E1e7ae15410B37Db674955335E8Fd722cb3e6",
            "0xc34E1e7ae15410B37Db674955335E8Fd722cb3e6",
            "0xc376DE0f2e83a08E133b1ed6a92BBeBb4947574F",
            "0xc3f5b8ccc8f0cfb4bcf6f1778ed0824aca9e523e",
            "0xC418bDbd903f25b375D1AD43C83Ffe15061cd3Ef",
            "0xc43904929c10D843E9Bd0E201A272Eb63c0c736c",
            "0xc43904929c10D843E9Bd0E201A272Eb63c0c736c",
            "0xC440d7d2eE529a2637256EA0C5359682D8A72aBF",
            "0xc4cAB02a5Ed2768E56cFfA5D2Fb7068cE3bCd847",
            "0xC539AC0aaE0a5f1B1A0C0dB9d5bBD2E6D4d50288",
            "0xC5636c3bBA6e27119500eD59e6aF5268f49B0A74",
            "0xc59f2589aFC329Bd0008D7Ce19348031dffA28aa",
            "0xC5Ef616993DA1681Cbe065516A468b525Ff7D5f6",
            "0xC619F35ee2AE78cF855E511F9940ee81a84e5212",
            "0xc6435aDaB7E5c70fe29fA0aBE3656a435B4ab546",
            "0xc657b33DB70d32628CBA9025607814B854C8Ff7E",
            "0xC848B03Cd813FdbfdbD4A1b8cA599c1fB6CF4Bc6",
            "0xC8880D9d6998352121dC6505987116614B55079F",
            "0xC89D096D9652899B3BB0151dcFc6aeC14824FC76",
            "0xc8B8c11a61fAaf2e159F20dE4cab91c8fbeb759a",
            "0xC8c1237726BB1308964A96309639cc5EA52EB687",
            "0xc8D09A2896A4578BaBFd338D0be63B41423C6b0f",
            "0xC8f9711387A6E6966D039B554d656a5c375cA97E",
            "0xc906b9d82B0E6DE0530bcFB94ef30eb03B3D4267",
            "0xC91C44BB5CF06AaeEA920f9A6a9736D4f533E647",
            "0xc9A3623B56D4B486219482abF3b1C7C753CE4D95",
            "0xC9C0786Cd5179ca400e5Ed5c3e896AB062d62452",
            "0xc9c96Aa20B0AA43cEaE7f7AA5118E6037a9Bd9DE",
            "0xcA0D5C02DeDe06122f571A1A7498D2625Fa2CEca",
            "0xCA8eb11BF2aE7D6163FB9B67c9eaa61a4307D46e",
            "0xCADc3E83BfBDD24d16829E629D395179606F952E",
            "0xcAfEd1BA693A4ee91cef017012d42d643AAfE8cB",
            "0xCb5d9Cf80AC372A725adAbCe1b27D5FCE84FA386",
            "0xcb660dd0B1D7fe7A7A3AC14840E879dc67ee19FE",
            "0xcB7b8A1DBE163cB3CCff2fbc4E55BcA30cDA300A",
            "0xCC0710c15F90aCB66BDD20A422310d20Bb805c86",
            "0xCc64a7Aa38cbf1FbD677878aE0dEA0E6E3287b7B",
            "0xcd71315c21bab6eCe689c387fFB074696f2ec5a7",
            "0xcD7ADB489a7ecE6efbB08F8786A2C917F6A421A9",
            "0xcdADbC9E40689cb4F76f50dE1bfca83dc872333f",
            "0xcdC489dA243D781DbC08a5F446F5915B62cAf65D",
            "0xcE44fB91744cE5ddaC0a28B70910e07e18E199a7",
            "0xce6AcD1AFDb505ac694F8a20F9E63dcd30a591E8",
            "0xCe8731b9a908608385E5ef6f4c4FCA9B5e75b485",
            "0xCf2f6Eae5F3Ab49BE5f7fbfC2AE6B11055ef3F2B",
            "0xD0eb7EFBf67AC9CC053D426df7B15E99FCF395a5",
            "0xD139039Ac4Abe0d6cCA88986b4Bcc39EdB817064",
            "0xd1b6F43d73d97b3BDC4a99357ABF4145ADFD70F7",
            "0xd25e403f37d6C9d8D784855D2268D93b450f9923",
            "0xd26D869424dd6194f9f1Ec018b8A9aa3b9DD4aA8",
            "0xD29126e4235551006331437DE4574a2F2BDc840d",
            "0xd29548BA3Ec4e7CA34e7E553d1FCfbcD5f6f9b41",
            "0xd33eF7FA8563e80BBc4cc3bCCB02bF4f965e1688",
            "0xd353848c9C50B11a7F5E4d4980e74f242C68AFFc",
            "0xD39255C361B5f5eCd64569c07a91B457E529ED5a",
            "0xD39fC9D9f9fC7A3ecE9b732E765FFAB09aE53e2b",
            "0xd3bFc9394b536657460cEC4D28490F8a175E7827",
            "0xd42D07891dF502613b570D55C2C228e42968Afeb",
            "0xD4329043b7ac556A950ABB6A9B37Ff1b70f0968C",
            "0xd469F7e53589Db2A9fF1Cc53b6ADD6eB4c49D1C2",
            "0xd4aa18a5E9C1bdEcb4F97cf31928De7936b1654C",
            "0xD4D27FbD73fBa326282f3bf178Ed569CcbC4F9b5",
            "0xD580b71e2094c8b89C5c15413C3638b94F3d166b",
            "0xd60DC7A24fB50D80bC4Ec9bfa9D50C199398b9B4",
            "0xd65a09670aE3eBF98bd5B75A1f6533065f12Fb5C",
            "0xd6c6Daa5320D7C2C8a2c8870C3BDe7c10099C0eF",
            "0xD6d57d174BE03101c29C1EB3a335559014896BC7",
            "0xd6fA29dc1a4DB2CA919B2428FA39AfeC716C96d6",
            "0xD70830eB270c9F0fCDA675c611772e363905EB27",
            "0xD755A4CF7677e12ea8f16468b18aeDDC1fa0dB5B",
            "0xd772438Ecae2D5225632e8C47dBb0f45Bb48C2d0",
            "0xd79a9865F5866760B77D7f82e35316662dEC6793",
            "0xD7b1bA82F8b606CB8ABeB7dAC0Dd971258ca3c8f",
            "0xD7f4b300430e332f6A64b34DC6378AcD6d002260",
            "0xD7fb570Dc78D09e33FDA93F79b6FDEdFC7D8e76E",
            "0xd87Fd565D3a9ccFAf8B5628b4b37663058327114",
            "0xd891B82e005491f57abdE7d1a6A36fAbd75E65B7",
            "0xd8aD795D8B024589c3fC31c673c5dd005c2979a3",
            "0xd8c95fdecBe38596B077c5E720F2a44529B7E3d7",
            "0xD8e5980113F74aCBb0abf9Aa980555dc04709ecF",
            "0xd90CeA3F7f17dCa6D67EC6Fcd8F0dF767e8dF48b",
            "0xd90dFDa20Ec78180656EC83b7135399a022B8dBA",
            "0xd9126D571e4521615FDBE8B907A696d359a8c2e2",
            "0xD91DC7c83bd01b91Cb25019DFc4E35BC6FaaB814",
            "0xd928CE1C7577dB5bE2575BcE3d52123882598d0B",
            "0xD9bda96bff79B8b59831fc7B08Dc6e37D68114Bf",
            "0xDa2a6295A6223e15D2E1Bb3F03539bE74c376580",
            "0xdaB48129E631b3f9E5885BCD49E2B298c4C115eB",
            "0xDaD3629b7fDB24C91f9953d38e6dc56D47Da0AC3",
            "0xDADedd5be7F3fE09F80A6ffCe1B713e2Fbb58b0E",
            "0xDADedd5be7F3fE09F80A6ffCe1B713e2Fbb58b0E",
            "0xdB03386fa0c72628A4D8a043a1384C532684503C",
            "0xDbf7E19a4FbCA4a2cD8820ca8A860C41fEadda90",
            "0xDC0D08c6bC98EcDf176941DE7517018f613E8977",
            "0xDC2b8297807e28773719a38be042b6ab810270a8",
            "0xdcbe5D6853FB8479ae14b593c5892995f59A8bcE",
            "0xDccFCA75cc2FF91087688FB6b8C8aA591f237E83",
            "0xdd8842eCA6Cd5316FDB8F75A0e7ea756db01c9c7",
            "0xdD8e7634769333D502db36Ea6f47becc1c978CF4",
            "0xdDCad16d8B9a51c06d8267249f59501E0b17ceF6",
            "0xdDE5C9AB1f3aBAF7Fe5af5A8e61d153fBD389a8F",
            "0xDdf5106d6b3746E04CB424028f194369fBe7dAaE",
            "0xde8F90845F0B8c1581E841Fc58dDc7e780902fE4",
            "0xdec9Bd2f6C2c094Dbc072179016f884b01b01f4A",
            "0xdf20F166Ce953c233cFddC6d7D3461f26Cca8049",
            "0xdf74719066AA57886ee20F0F655EB8d6C16c3De2",
            "0xdf8e3138F6f7Dcb5ceF9fBF1555Eb24dcAe3a311",
            "0xE08CCA32Aff4cF0B977E0037404c24768a10f9DB",
            "0xE0B5129743059da34D9f2044dfE2450dBeDba22A",
            "0xe183715C18072d9C64A8081D0d6C0762465bDf72",
            "0xE18a9F69Da0E61c8B5f234b519cd5f567eDe808f",
            "0xe1B0F2A5B367bC821fBA79AF4EbD063C8210ee1c",
            "0xe2116f7131DB923f9Bd7c5A5C75f34F376790BE8",
            "0xe211c9CF20364021980Fff5De4E21667548B65a1",
            "0xe2320De5d2ddA68A9479E4271b704284679E49eb",
            "0xe2320De5d2ddA68A9479E4271b704284679E49eb",
            "0xe24404999E4F75e19153bc6315d465bf0F05Fa9d",
            "0xe268F03eBe44B04768c5E5eb0F7CbdB12F121368",
            "0xE2a521a2d9CfE13B6135D6814310A9aFA00970d8",
            "0xE2a521a2d9CfE13B6135D6814310A9aFA00970d8",
            "0xe2b0A4432caaE8c107A1D5F9820e3A34E27b4130",
            "0xe300DD7bd1c79aa78ED4217b482ec9f95De7fBb1",
            "0xe309093D5582146F03AfA90D701e7fF8cFF7Ac72",
            "0xe3B7861867143eF8c93cE56266483BDA3DAAe388",
            "0xe3B7861867143eF8c93cE56266483BDA3DAAe388",
            "0xE3C567184aa25767963ff1E74Ef7d1b27F32bB0d",
            "0xE3D6809aF3e37a165F42F9BbAb9CD940eb45261e",
            "0xE4dF7AFaBE10c541cCf470EC5cB689370935e83F",
            "0xE4eD0Dd880ae6B5761F8C73f38509A4d377021BA",
            "0xe50E67bDB542340647Af845e94E1F6926b24c181",
            "0xe55766ED567F2ECb1fC0a30eD07c35d659996Eb3",
            "0xe56085F2d5a7FB4FE0A9e86E139671F8df5b91e5",
            "0xE5A6a90f09F2e2578423146C5Cd04cdB8750bFE5",
            "0xe61426622Fa54Fb2ADc7D5bd93178a1a7F12ae45",
            "0xE6bc6acAF9CB73FDE958E8f1F6BB436BF1B43EC1",
            "0xE7493C3FDDd57E85Ef36043AC02B44B35be22010",
            "0xe77064473BE26ce57405f2aAa341470d9626f725",
            "0xE79347066A042a40ac9facB700680b7CAaED769B",
            "0xe7BF57eE1402C68dB28dbcc1F43427CEd2C4218a",
            "0xe86d3965969460dE3F960439380B39E9539fD673",
            "0xE8fcD7BDb10280786a5b81FFDE44924b12D1F038",
            "0xe9099ffeeca205007e5e34269093496723f51931",
            "0xE953863a6f5317b8D226AB07cbAE97f6B63a0373",
            "0xe98fF2db3DC76984eC408Ec4113eCfE83eAF715F",
            "0xE9c2D22736aeBd78b0DAC9676145560295603326",
            "0xEa1f7Fb5728d90a359f062ff4D856DABE8b2555c",
            "0xeA6ae8cc94a472CCA8b19cBbc0fa0a36898047d6",
            "0xeaaEaC965449d2426F6F793770b4f3560eeB7c0F",
            "0xEB6E5DCF8e854c78d2f1C64dB0ca95fF0Bb86068",
            "0xEb96B2f64Bb52Cc4B7c79373714B4f4A6c3dC037",
            "0xebE9f2bBD5e7b3b8099233aFff654c6a9BaC679C",
            "0xec4551C3eF737F737733F051F2082b5de806EaBA",
            "0xeC593be7fC97779C861BBBdeB1eE1A1B516B89f0",
            "0xECd48e2e7c671da557a4976e1D0eAD1163D1423D",
            "0xed19d89F9b6e7631Eb12BF085e197ce68ACD47D9",
            "0xED66f2ca147e4A8B15f3646D5e8DAf7C6B7405af",
            "0xed7ad5c39f972ba55cd1010ec41c6412e04e3aca",
            "0xEde46d06a39e7a3B70B1A6492a95E6648c2fd6f5",
            "0xeE9157bcB33737d3402BA2Ae50793F7bAFe8b5E3",
            "0xeEf0c3cA47Ee2B81f921FF30A381552F773A5bd2",
            "0xeffEED4D0f9B4d5b911f6C8aB8941f62B928662A",
            "0xf0307C4b686bb6fc0101451f1B31402271cd4bef",
            "0xf030C1ED247FE73221fb678983C07ea842e8371D",
            "0xF039f877B945a8Ab3E72E7c0685584da8a15508A",
            "0xF051B3107529c85c97FdE99D7feB14BCa8caED91",
            "0xF0e3bf7Df5fcD0e25cbe0C9646928063af24727e",
            "0xf1c3b62c757dd0c3870c881c4d2c0213d4453d44",
            "0xf20C8002A384CFb0eC91971FFaEeD521d0cd241b",
            "0xf20C8002A384CFb0eC91971FFaEeD521d0cd241b",
            "0xF21a309D02ffAd0C133577e50937892C4643B709",
            "0xf24f912198BE370258EFc315de6E484f465A3677",
            "0xF2A5c44F7569caEb6C87d6747Dd3e1dBE8d17ecA",
            "0xf2Cd6868586164E850260D56e0eB05DA4641FEE3",
            "0xf352C2010dF0695B1bA4f8AeF3430D53121EE6d9",
            "0xF3b0002280DA4C87E3F36A3c9a4F1E142a762062",
            "0xf3e58585C08B45a0Ec47414dC4C798A8ba677244",
            "0xF41ea0864D907796A495F9265AA56d2b6307C343",
            "0xf443952321206BDe96f4689341B842D1B3eb4376",
            "0xf44e8ff03F794774cD67c937feC72080B05d0aed",
            "0xf47Ac3c416022A7ADeDa68571EcbB86d91469A24",
            "0xF48B231fd43bEFd3F6c30f0648A485026aff41f5",
            "0xF4CA8bCF50c4F09b3F758925395f171c00859050",
            "0xf4F96b4b81ACc5879DF1D1fCA97410eB972e7745",
            "0xF610fBDc2570Eac449619395Ce964D4De12f7ff3",
            "0xf63915dff43E25898313C538BA5648B6A5FeDa4f",
            "0xf64733e2e67d2527308D1a115FDeFd3A7e6141b7",
            "0xF709847Ce7fAF3B31F48221ef47B553ED90Fd3Dc",
            "0xF7265b8C713F12d76eE4483b5eea4fb7889741BC",
            "0xF7265b8C713F12d76eE4483b5eea4fb7889741BC",
            "0xF7dfD2A3ea1036e103dbfe8227bc440A5E113e93",
            "0xf7Ec922c23881fA477460b6f2c6F9cE0a17Dfc86",
            "0xf8091a1a3055c9a8a7492e7dcc31162d000747c7",
            "0xF8305d7ab9Ba2350011A87Db3DB585BC9a80e5b0",
            "0xf8366A2cA5B0d8aF448a32c4a842c553c70043E6",
            "0xF845E6908b0803F54E05253C040eFE0A571AA91b",
            "0xf86756f5297c25f6a8Ee3f7655EE7dF0a29a350c",
            "0xF8721fA5f901f95F875331f002a1F0402caCF6Dc",
            "0xf8bB7A9E5E6a73E34AeDd42E7d1Ce962311AE73E",
            "0xf8f9042A6359065A2d279B280580478fC2934aBe",
            "0xf934d60da1F027D0b9B6cAA52bDE6583eb171f46",
            "0xf941E451E2eFBC9f6753c6B51881A537EB2A75Cd",
            "0xF9fD07e72c5da48a471aB8d93A7065F59Fba627D",
            "0xfb3156C2EeA76EbC44e9C292605527be3D7Aad87",
            "0xfB7757BC48Ac5d353c9E202b32a2360e0E821e51",
            "0xfCcEa0B14D4340826Bf1090875229dA599b1fb4e",
            "0xFD0da64406a3E52b0EAFFF28Bbc46BAf86205E13",
            "0xfd114BeeDf4b7DBA7722001D737151b5974Be06a",
            "0xFd25bFD8cbf9e63EDA32616ca2C47fB9c863f789",
            "0xfDA009d39d7D9af72fF21A33d528733a43b6aB54",
            "0xfdC6f75a5e0cD04D3D6bc17577440f43a7963972",
            "0xfdf9811f657f07EA91b9d92366A80357dB52aaBA",
            "0xfE13A69994743AE68053CCC7A4d601d2B63c9318",
            "0xFE64736dF276de2aa0A4aEe0ED3fcA4B7847531f",
            "0xFeBeC31bDf1972c42E683476B89b40D9871A62f5",
            "0xFede894631Fad7EEdD8344Bd6643654Bea203F5B",
            "0xfee82A2aEe6cE9B1f5c445AD8aa337b7A9Ccb299",
            "0xff96101caf17836C4c96549d6a83485341590B94",
            "0xFfAef2Fe850c1A8B5A0b6E14f28735b099e58438",
            "0xfFFFE96D5dF4b535022Bcf9A901716bA3eBD8a82",
            "0x760c5A41b67BE0b8E208Da61c9654d5aad1e92f2"
    ];

    const leafNodes  = await whitelistAddress.map(addr => keccak(addr));
          markelTree = await new tree(leafNodes, keccak, {sortPairs: true});
    const roothash = await markelTree.getRoot().toString('hex'); 
    console.log(roothash);
    // 0x and then roothash add into smart contract
    var web3 = new Web3('https://mainnet.infura.io/v3/25fe98fb45cd437cab07709241cf6be0');
    contract = new web3.eth.Contract(abi, contractAddress);

    let SALE_NFT = await contract.methods.SALE_NFT().call();
    let MAX_MINT_IN_SALE = await contract.methods.MAX_BY_MINT_SALE().call();
    let SALE_NFT_MINTED = await contract.methods.SALE_MINTED().call();
    let SALE_PRICE = await contract.methods.SALE_PRICE().call();
    saleEnable = await contract.methods.saleEnable().call();

    let PRESALE_NFT  = await contract.methods.PRESALE_NFT().call();
    let MAX_MINT_IN_PRESALE = await contract.methods.MAX_BY_MINT_PRESALE().call();
    let PRESALE_NFT_MINTED = await contract.methods.PRESALE_MINTED().call();
    let PRESALE_PRICE  = await contract.methods.PRESALE_PRICE().call();
        MAX_BY_MINT_IN_TRANSACTION  = await contract.methods.MAX_BY_MINT_IN_TRANSACTION().call();
    presaleEnable  = await contract.methods.presaleEnable().call();

    if(saleEnable) 
    {
         MintLimit = MAX_MINT_IN_SALE;
         $("#AVAILABLE_TO_MINT").html(SALE_NFT);
         remaningNFT = SALE_NFT - SALE_NFT_MINTED;
         if(SALE_NFT==SALE_NFT_MINTED) 
         {
            $("#mint-nft").html('All NFT Sold');
            $("#mint-nft").attr("disabled", true);
         }
         NFTprice = SALE_PRICE/10**18;
         $("#remainingMint").html(remaningNFT);
         $("#totalMint").html(SALE_NFT_MINTED);
         $("#ETH").html(NFTprice);
     }
     else if(presaleEnable)
     {
         MintLimit = MAX_MINT_IN_PRESALE;
         $("#AVAILABLE_TO_MINT").html(PRESALE_NFT);
         remaningNFT = PRESALE_NFT - PRESALE_NFT_MINTED;
         if(PRESALE_NFT==PRESALE_NFT_MINTED) 
         {
            $("#mint-nft").html('All NFT Sold');
            $("#mint-nft").attr("disabled", true);
         }
         NFTprice = PRESALE_PRICE/10**18;
         $("#remainingMint").html(remaningNFT);
         $("#totalMint").html(PRESALE_NFT_MINTED);
         $("#ETH").html(NFTprice);
     }
     else
     {
           MintLimit = 0;
           $("#mint-nft").html('Minting Paused');
           $("#mint-nft").attr("disabled", true);
           buttondisplay="No"
     }

     if(MAX_BY_MINT_IN_TRANSACTION > MintLimit)
     {
         MAX_BY_MINT_IN_TRANSACTION = MintLimit;
     }

     const providerOptions = {
         walletconnect: {
          package: WalletConnectProvider,
          options: {
            infuraId: "25fe98fb45cd437cab07709241cf6be0",
            chainId: 1,
          }
        }
      };
      web3Modal = new Web3Modal({
        cacheProvider: false,
        providerOptions, 
      });
      console.log("Web3Modal instance is", web3Modal);

}

function priceChnage()
{
    var count = parseInt($("#input-quantity").val());
    var price = (count * parseFloat(NFTprice)).toFixed(3);
    $("#ETH").html(price);
}

async function init2() {
        const web3 = new Web3(provider);
        contract = new web3.eth.Contract(abi, contractAddress);
        web3.eth.getAccounts(function(err, accounts) {
            if (err != null) {
                swal({
                    title: "Error Found",
                    text: err,
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else if (accounts.length === 0) {
                swal({
                    title: "Error Found",
                    text: 'Your Wallet is Locked. Please Unlock It To Use DAPP',
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else if (web3.currentProvider.chainId != 1) {
                swal({
                    title: "Error Found",
                    text: 'Make Sure You Are Using The ETH Network',
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else {
                userAddress = accounts[0];
                userStatsUpdate();
            }
        });
}

async function userStatsUpdate() 
{
    if(buttondisplay=="Yes" && saleEnable)
    {
        var getPreSaleMinted  = await contract.methods.users(userAddress).call();
        if(MintLimit==getPreSaleMinted.salemint)
        {
            $("#mint-nft").html('Already Minted');
            $("#mint-nft").attr("disabled", true);
        }
        MintLimit = MintLimit-getPreSaleMinted.salemint;
    }
    else if(buttondisplay=="Yes" && presaleEnable)
    {
        var getPreSaleMinted  = await contract.methods.users(userAddress).call();
        if(MintLimit==getPreSaleMinted.presalemint)
        {
            $("#mint-nft").html('Already Minted');
            $("#mint-nft").attr("disabled", true);
        }
        MintLimit = MintLimit-getPreSaleMinted.presalemint;
    }
    if(MAX_BY_MINT_IN_TRANSACTION > MintLimit)
    {
        MAX_BY_MINT_IN_TRANSACTION = MintLimit;
    }
    $("#wallet-connect").hide();
    $("#mint-nft").show();
}

async function mint() {
    try {
        $("#error").html('');
        var count = parseInt($("#input-quantity").val());
        var price = count * NFTprice * 10**18;
        if(count==0)
        {
           $("#error").html('Mint Atleast 1 NFT');
        }
        else if(count > remaningNFT)
        {
            $("#error").html("Can't Mint More Than Remaning NFT");
        }
        else if(count > MAX_BY_MINT_IN_TRANSACTION)
        {
             $("#error").html("Can't Mint More Than "+MAX_BY_MINT_IN_TRANSACTION+" NFT");
        }
        else
        {
             if(saleEnable)
             {
                    contract.methods.mintSaleNFT(count).estimateGas({from: userAddress, value: price}).then(function(gasAmount){
                        contract.methods.mintSaleNFT(count).send({from: userAddress, value: price}, function(error, tx) {
                            if (error) {
                                swal({
                                    title: "Error Found",
                                    text: error.message,
                                    type: "error",
                                    showCancelButton: false,
                                    confirmButtonClass: "btn-danger",
                                    confirmButtonText: "Ok",
                                    closeOnConfirm: false
                                });
                            } else {
                                swal({
                                    title: "Mint Request Submitted Successfully",
                                    text: "Please Wait For Wallet Confirmation",
                                    type: "success",
                                    showCancelButton: false,
                                    confirmButtonClass: "btn-danger",
                                    confirmButtonText: "Ok",
                                    closeOnConfirm: false
                                });
                            }
                        }); 
                      })
                      .catch(function(error){
                          swal({
                            title: "Error Found",
                            text: 'Insufficient Funds For Transection in Wallet',
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                           });
                      });
             }
             else if(presaleEnable)
             {
                   var claimAddress = keccak(userAddress).toString('hex');
                   const merkleProof = markelTree.getHexProof(claimAddress);
                   if(merkleProof=="" || merkleProof==undefined)
                   {
                       swal({
                            title: "Error Found",
                            text: 'Your Address Is Not WhiteListed For Pre-Sale',
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                        });
                   }
                   else
                   {
                           contract.methods.mintPreSaleNFT(count,merkleProof).estimateGas({from: userAddress, value: price}).then(function(gasAmount){
                              contract.methods.mintPreSaleNFT(count,merkleProof).send({from: userAddress, value: price}, function(error, tx) {
                                    if (error) {
                                        swal({
                                            title: "Error Found",
                                            text: error.message,
                                            type: "error",
                                            showCancelButton: false,
                                            confirmButtonClass: "btn-danger",
                                            confirmButtonText: "Ok",
                                            closeOnConfirm: false
                                        });
                                    } else {
                                        swal({
                                            title: "Mint Request Submitted Successfully",
                                            text: "Please Wait For Wallet Confirmation",
                                            type: "success",
                                            showCancelButton: false,
                                            confirmButtonClass: "btn-danger",
                                            confirmButtonText: "Ok",
                                            closeOnConfirm: false
                                        });
                                    }
                              }); 
                          })
                          .catch(function(error){
                              swal({
                                title: "Error Found",
                                text: 'Insufficient Funds For Transection in Wallet',
                                type: "error",
                                showCancelButton: false,
                                confirmButtonClass: "btn-danger",
                                confirmButtonText: "Ok",
                                closeOnConfirm: false
                               });
                          });
                   }
             }
        }
    } catch (error) {
        swal({
            title: "Error Found",
            text: error,
            type: "danger",
            showCancelButton: false,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            closeOnConfirm: false
        });
    }
}