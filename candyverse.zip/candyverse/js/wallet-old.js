
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const Fortmatic = window.Fortmatic;
const evmChains = window.evmChains;
let web3Modal
let provider;
let selectedAccount;
let remaningNFT;

$("#mint-nft").click(function(e) {
    mint();
});

$("#wallet-connect").click(function(e) {
    onConnect();
});

$("#wallet-connect-2").click(function(e) {
    onConnect();
});

$('.do-min').click(function() {
    if (isNaN($('input[name=\'quantity\']').val() / 1) == false) {
        var quantity = $('input[name=\'quantity\']').val();
    } else {
        var quantity = 1;
    }
    if ($('input[name=\'quantity\']').val() > 1) {
        $('input[name=\'quantity\']').val(parseInt(quantity) - parseInt(1));
    }
    priceChnage();
});
$('.do-plus').click(function() {
    if (isNaN($('input[name=\'quantity\']').val() / 1) == false) {
        var quantity = $('input[name=\'quantity\']').val();
    } else {
        var quantity = 1;
    }
    $('input[name=\'quantity\']').val(parseInt(quantity) + parseInt(1));
    priceChnage();
});

$("#input-quantity").change(function(e) {
    priceChnage();
});

window.addEventListener('load', async () => {
    init();
});

async function onConnect() {
    console.log("Opening a dialog", web3Modal);
    try {
        provider = await web3Modal.connect();
    } catch (e) {
        console.log("Could not get a wallet connection", e);
        return;
    }
    provider.on("accountsChanged", (accounts) => {
        init2();
    });
    provider.on("chainChanged", (chainId) => {
        init2();
    });
    provider.on("networkChanged", (networkId) => {
        init2();
    });
    await init2();
}

var abi = [{"inputs":[{"internalType":"string","name":"baseURI","type":"string"}],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"owner","type":"address"},{"indexed":true,"internalType":"address","name":"operator","type":"address"},{"indexed":false,"internalType":"bool","name":"approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"uint256","name":"id","type":"uint256"}],"name":"CreateSOLDZ","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Paused","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"from","type":"address"},{"indexed":true,"internalType":"address","name":"to","type":"address"},{"indexed":true,"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"internalType":"address","name":"account","type":"address"}],"name":"Unpaused","type":"event"},{"inputs":[],"name":"GIVEAWAY_MINTED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"GIVEAWAY_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_BY_MINT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"MAX_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"PRICE","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_MINTED","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"SALE_NFT","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"baseTokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_to","type":"address"},{"internalType":"uint256","name":"_count","type":"uint256"}],"name":"mintGiveawayNFT","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_count","type":"uint256"}],"name":"mintSaleNFT","outputs":[],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"bool","name":"val","type":"bool"}],"name":"pause","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"paused","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_count","type":"uint256"}],"name":"price","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[],"name":"saleEnable","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"baseURI","type":"string"}],"name":"setBaseURI","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"_status","type":"bool"}],"name":"setSaleStatus","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updateGiveawayLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newSupply","type":"uint256"}],"name":"updateMaxSupply","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newLimit","type":"uint256"}],"name":"updateMintLimit","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"newPrice","type":"uint256"}],"name":"updatePrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"}],"name":"walletOfOwner","outputs":[{"internalType":"uint256[]","name":"","type":"uint256[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"}];
var contractAddress = '0x8fbD2F5C6E5a6428B2dC634079d7217F4d5b4242';
var userAddress = '';
var contract = undefined;
var saleEnable;
var presaleEnable;
var MintLimit;
var price = 0;

async function init() {
    var web3 = new Web3('https://rinkeby.infura.io/v3/25fe98fb45cd437cab07709241cf6be0');
    contract = new web3.eth.Contract(abi, contractAddress);

    let TOTAL = await contract.methods.SALE_NFT().call();
    let TOTAL_MINTED = await contract.methods.SALE_MINTED().call();
        price = await contract.methods.PRICE().call();
        price = price/10**18;
        MintLimit = await contract.methods.MAX_BY_MINT().call();
        saleEnable = await contract.methods.saleEnable().call();
        
    remaningNFT = TOTAL - TOTAL_MINTED;
    if(TOTAL==TOTAL_MINTED) 
    {
        $("#mint-nft").html('All NFT Sold');
        $("#mint-nft").attr("disabled", true);
    }
    else if(!saleEnable)
    {
        $("#wallet-connect").attr("disabled", true);
        $("#wallet-connect").html('Minting Disabled');
    }
    $("#totalMint").html(TOTAL_MINTED);
    $("#totalSupply").html(TOTAL);

    $("#ETH").html(price);
    const providerOptions = {
         walletconnect: {
          package: WalletConnectProvider,
          options: {
            infuraId: "25fe98fb45cd437cab07709241cf6be0",
            chainId: 4,
          }
        }
      };
      web3Modal = new Web3Modal({
        cacheProvider: false,
        providerOptions, 
      });
      console.log("Web3Modal instance is", web3Modal);
}

function priceChnage() {
    var count = parseInt($("#input-quantity").val());
    if(MintLimit > 0 && count > MintLimit)
    {
         var Newprice = (MintLimit * parseFloat(price)).toFixed(2);
         $("#input-quantity").val(MintLimit);
         $("#ETH").html(Newprice);
    }
    else
    {
         var Newprice = (count * parseFloat(price)).toFixed(2);
         $("#ETH").html(Newprice);
    }
}

async function init2() {
        const web3 = new Web3(provider);
        contract = new web3.eth.Contract(abi, contractAddress);
        web3.eth.getAccounts(function(err, accounts) {
            if (err != null) {
                swal({
                    title: "Error Found",
                    text: err,
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else if (accounts.length === 0) {
                swal({
                    title: "Error Found",
                    text: 'Your Wallet is Locked. Please Unlock It To Use DAPP',
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else if (web3.currentProvider.chainId != 4) {
                swal({
                    title: "Error Found",
                    text: 'Make Sure You Are Using The Rinkeby Network',
                    type: "error",
                    showCancelButton: false,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Ok",
                    closeOnConfirm: false
                });
            } else {
                userAddress = accounts[0];
                userStatsUpdate();
            }
        });
}

async function userStatsUpdate() 
{
    if(!saleEnable )
    {
         $("#wallet-connect").attr("disabled", true);
         $("#wallet-connect").html('Minting Disabled');
    }
    else
    {
        $("#wallet-connect").hide();
        $("#mint-nft").show();
    }
}

async function mint() {
    try {
        $("#error").html('');
        var count = parseInt($("#input-quantity").val());
        var Nprice = count * price * 10**18;
        if(count==0)
        {
           $("#error").html('Mint Atleast 1 NFT');
        }
        else if(count > remaningNFT)
        {
            $("#error").html("Can't Mint More Than Remaning NFT");
        }
        else if(count > MintLimit)
        {
             $("#error").html("Can't Mint More Than "+MintLimit+" NFT");
        }
        else
        {
             if(saleEnable)
             {
                       contract.methods.mintSaleNFT(count).estimateGas({from: userAddress, value: Nprice}).then(function(gasAmount){
                            contract.methods.mintSaleNFT(count).send({from: userAddress, value: Nprice}, function(error, tx) {
                                if (error) {
                                     swal({
                                        title: "Error Found",
                                        text: error.message,
                                        type: "error",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-danger",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    });
                                } else {
                                    swal({
                                        title: "Mint Request Submitted Successfully",
                                        text: "Please Wait For Wallet Confirmation",
                                        type: "success",
                                        showCancelButton: false,
                                        confirmButtonClass: "btn-danger",
                                        confirmButtonText: "Ok",
                                        closeOnConfirm: false
                                    });
                                }
                            });
                      })
                      .catch(function(error){
                          swal({
                            title: "Error Found",
                            text: 'Insufficient Funds For Transection in Wallet',
                            type: "error",
                            showCancelButton: false,
                            confirmButtonClass: "btn-danger",
                            confirmButtonText: "Ok",
                            closeOnConfirm: false
                           });
                      });  
             }
        }
    } catch (error) {
        swal({
            title: "Error Found",
            text: error,
            type: "danger",
            showCancelButton: false,
            confirmButtonClass: "btn-danger",
            confirmButtonText: "Ok",
            closeOnConfirm: false
        });
    }
}