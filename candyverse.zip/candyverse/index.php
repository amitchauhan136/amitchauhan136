<!DOCTYPE html>
<html lang="eng"  data-wf-page="609ee5af1248074f52018772" >
    <head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="cache-control" content="no-cache" />
        <link rel="shortcut icon" href="img/cropped-dreamstime_161384638-Converted-192x192.png" type="image/x-icon">  
		<meta http-equiv="Pragma" content="no-cache" />
        <title>Candyverse | NFT and Metaverse</title>
    	<link rel="shortcut icon" type="image/png" href="">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css" rel="stylesheet">
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style-latest.css" rel="stylesheet">

		<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,700i,800&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Concert+One&display=swap" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" rel="stylesheet">
   </head>
   <body>
<div class="header_area clearfix" id="back-top-here">
	<nav class="navbar navbar-default clearfix">
	  <div class="container">
		<div class="navbar-header clearfix">
		  <button type="button" class="navbar-toggle navbar-toggle-my" data-toggle="collapse" data-target="#myNavbar">
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>                        
		  </button>
		  <a class="navbar-brand logo" href="./"><img src="img/candyverselogo.png" style=""></a>
		</div>
		<div class="navbar-collapse collapse clearfix " id="myNavbar">
		  <ul class="nav navbar-nav navbar-right">
			<li class="nav_tn"><a href="https://candyverse.io/" target="_blank">Main Site <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
		  </ul>
		</div>
	  </div>
	</nav>
	<div style="clear:both"></div>
</div>
<div class="min_section padding_section">
	<div class="mint_here">
	<div class="container">
		<div class="main_m_body text-center">
				<div class="logo_section">
					<img src="img/candyverselogo.png" class="img-responsive">
				</div>
              <h1><a href="" data-animation-role="header-element" class="preFade fadeIn">THE SWEETEST NFT AND METAVERSE PROJECT</a></h1>
              <p>We are not alone in the universe.</p>
              <p>Discover other worlds with Candyverse NFT.</p>
              <div class="Main_btn_form">
                <h4>MINT</h4>
                <div class="minus_plus_here">
                  <div class="input-group">
                    <button type="submit" class="btn btn-success min do-min">-</button>
                    <input type="text" name="quantity" value="1" size="2" id="input-quantity" class="form-control">
                    <button type="submit" class="btn btn-success plus do-plus">+</button>
                  </div>
                  <div id="error"></div>
                  <h4><span id="ETH">0.0</span> ETH + Gas Fee Required</h4> </div>
              </div>
              <div class="button_here">
               <button id="mint-nft" disabled="disabled">Minting Disable</button> 
               <?php /* ?>  <button id="mint-nft" >Mint NFT</button> <?php ?><?php */ ?>
                <button id="wallet-connect">Connect Wallet</button>
              </div>
            </div>
	</div>
</div>
<div class="white_here white_page">
	<div class="container">
        <div class="box_white main_m_body text-center">

				<div class="logo_section">
					<img src="img/candyverselogo.png" class="img-responsive">
				</div>
				<div class="white_vv">
              <h1><a href="" data-animation-role="header-element" class="preFade fadeIn">CHECK WHITELIST STATUS</a></h1>
	          <input type="text" name="" class="form-control" placeholder="Enter Wallet Address" id="wallet-address">
	          <div class="button_here ">
	          <button class="btn btn-success" id="go">Go</button>
	      </div>
	      </div>
        </div>
      </div>
</div>

</div>
    <div class="modal modal_white fade" id="success" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="main_m_body text-center">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="background:#b0b0b0;"> <span aria-hidden="true">&times;</span> </button>
              <h1>HORRY!</h1>
              <p>Your address is whitelisted.</p>
              <div class="button_here">
                <button class="" data-dismiss="modal" style="margin-bottom: 0px;">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="modal modal_white fade" id="sorry" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="main_m_body text-center">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="background:#b0b0b0;"> <span aria-hidden="true">&times;</span> </button>
              <h1 style="color:#ff3482;">Sorry, you just missed out.</h1>
              <p>Your adress is not whitelisted.</p>
              <div class="button_here">
                <button class="" data-dismiss="modal" style="">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

   <div class="modal modal_white fade" id="sorry2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-body">
            <div class="main_m_body text-center">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="background:#b0b0b0;"> <span aria-hidden="true">&times;</span> </button>
              <h1 style="color:#ff3482;">Sorry, your wallet address is blank or incorrect.</h1>
              <div class="button_here">
                <button class="" data-dismiss="modal" style="">Close</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/web3@1.2.11/dist/web3.min.js"></script>
<script type="text/javascript" src="dist/index.js"></script>
<script type="text/javascript" src="https://unpkg.com/evm-chains@0.2.0/dist/umd/index.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/@walletconnect/web3-provider@1.2.1/dist/umd/index.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/fortmatic@2.0.6/dist/fortmatic.js"></script>
<script src="https://cdn.jsdelivr.net/npm/merkletreejs@latest/merkletree.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/keccak256@latest/keccak256.js"></script>

<script type="text/javascript" src="js/wallet.js"></script>

  </body>
</html>